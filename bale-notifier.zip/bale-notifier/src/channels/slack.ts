import type { BaleEvent, NotificationChannel, SlackConfig } from "../types.js";

function formatEvent(event: BaleEvent): string {
  switch (event.type) {
    case "message":
      return [
        `*New Bale Message in ${event.source}*`,
        event.preview ? `Preview: ${event.preview}` : "",
      ].filter(Boolean).join("\n");

    case "call":
      return `*${event.callType === "video" ? "Video" : "Voice"} ${event.source}*`;

    case "group_notification":
      return [
        "*Bale Group Notification*",
        event.preview ?? "New activity",
      ].join("\n");

    default:
      return event.preview ?? event.source;
  }
}

export class SlackChannel implements NotificationChannel {
  constructor(private config: SlackConfig) {}

  async send(event: BaleEvent): Promise<void> {
    const text = formatEvent(event);
    const res = await fetch(this.config.webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    if (!res.ok) {
      throw new Error(`Slack webhook failed: ${res.status} ${await res.text()}`);
    }
  }

  async validateConfig(): Promise<boolean> {
    try {
      const res = await fetch(this.config.webhookUrl, { method: "HEAD" });
      return res.ok || res.status === 400;
    } catch {
      return false;
    }
  }
}