import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    globals: true,
    exclude: ["**/openclaw-main/**", "**/node_modules/**"],
  },
});
